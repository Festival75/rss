create function pg_catalog."overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, interval) returns boolean
LANGUAGE SQL
AS $$
select ($1, $2) overlaps ($3, ($3 + $4))
$$;
