create function pg_catalog.polygon(circle) returns polygon
LANGUAGE SQL
AS $$
select pg_catalog.polygon(12, $1)
$$;
